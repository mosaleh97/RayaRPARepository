using UiPath.CodedWorkflows;

namespace SystemDiagnosticsProcess
{
    public partial class CodedWorkflow : CodedWorkflowBase
    {
        public CodedWorkflow()
        {
            _ = new System.Type[]{};
        }
    }
}